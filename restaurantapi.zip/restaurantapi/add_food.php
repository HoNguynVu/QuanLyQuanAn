<?php
require 'db.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Phải dùng phương thức POST"]);
    exit;
}

$name = $_POST['name'] ?? '';
$price = $_POST['price'] ?? '';
$category = $_POST['category'] ?? '';
$image_url = $_POST['image_url'] ?? '';
$available = $_POST['available'] ?? 1;
$description = $_POST['description'] ?? ''; 

if (empty($name) || empty($price) || empty($category) || empty($image_url) || $available === '' ||  empty($description)) {
    echo json_encode(["status" => "error", "message" => "Thiếu dữ liệu"]);
    exit;
}

$stmt = $conn->prepare("INSERT INTO foods (name, price, category, image_url, available, description) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sdssis", $name, $price, $category, $image_url, $available, $description);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Thêm món thành công"]);
} else {
    echo json_encode(["status" => "error", "message" => "Thêm thất bại"]);
}
