// add_notification.php
include 'db_connect.php'; // kết nối database

$user_id = $_POST['user_id'];
$order_id = $_POST['order_id']; // có thể null nếu ko liên quan đơn hàng
$title = $_POST['title'];
$message = $_POST['message'];

$stmt = $conn->prepare("INSERT INTO notifications (user_id, order_id, title, message) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiss", $user_id, $order_id, $title, $message);
if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
$stmt->close();
$conn->close();
