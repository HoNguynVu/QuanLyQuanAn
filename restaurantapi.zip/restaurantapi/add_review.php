<?php
header('Content-Type: application/json; charset=utf-8');
require_once("db.php");

// Kiểm tra phương thức POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lấy dữ liệu từ client gửi lên
    $food_id = $_POST['food_id'] ?? null;
    $user_id = $_POST['user_id'] ?? null;
    $rating = $_POST['rating'] ?? null;
    $comment = $_POST['comment'] ?? '';

    // Kiểm tra dữ liệu đầu vào
    if (!$food_id || !$user_id || !$rating) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Thiếu dữ liệu đầu vào'
        ]);
        exit;
    }

    // Kiểm tra giá trị rating
    if ($rating < 1 || $rating > 5) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Giá trị rating không hợp lệ (1-5)'
        ]);
        exit;
    }

    // Chuẩn bị câu truy vấn
    $stmt = $conn->prepare("INSERT INTO reviews (user_id, food_id, comment, rating) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iisi", $user_id, $food_id, $comment, $rating);

    if ($stmt->execute()) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Thêm đánh giá thành công'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Lỗi khi thêm đánh giá: ' . $conn->error
        ]);
    }

    $stmt->close();
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Chỉ chấp nhận phương thức POST'
    ]);
}
?>
