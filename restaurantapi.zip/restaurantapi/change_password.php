<?php
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

$email = $_POST['email'] ?? '';
$old_password = $_POST['old_password'] ?? '';
$new_password = $_POST['new_password'] ?? '';

if (empty($email) || empty($old_password) || empty($new_password)) {
    echo json_encode(["status" => "error", "message" => "Thiếu thông tin"], JSON_UNESCAPED_UNICODE);
    exit;
}

// Kiểm tra mật khẩu cũ
$stmt = $conn->prepare("SELECT password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($stored_password);
if (!$stmt->fetch()) {
    echo json_encode(["status" => "error", "message" => "Người dùng không tồn tại"], JSON_UNESCAPED_UNICODE);
    $stmt->close();
    exit;
}
$stmt->close();

// So sánh mật khẩu
if ($stored_password !== $old_password) {
    echo json_encode(["status" => "wrong_password", "message" => "Mật khẩu cũ không đúng"], JSON_UNESCAPED_UNICODE);
    exit;
}

// Cập nhật mật khẩu mới
$stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
$stmt->bind_param("ss", $new_password, $email);
if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Đổi mật khẩu thành công"], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["status" => "error", "message" => "Lỗi khi cập nhật mật khẩu"], JSON_UNESCAPED_UNICODE);
}
$stmt->close();
?>
