<?php
require_once("db.php");
$dbName = $conn->query("SELECT DATABASE()")->fetch_row()[0];
echo "Đang kết nối đến database: <strong>$dbName</strong><br>";

$result = $conn->query("SHOW TABLES");
echo "Danh sách bảng:<ul>";
while ($row = $result->fetch_row()) {
    echo "<li>" . $row[0] . "</li>";
}
echo "</ul>";
?>
