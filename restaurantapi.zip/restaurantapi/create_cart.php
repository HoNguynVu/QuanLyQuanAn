<?php
require_once 'db.php'; // Kết nối MySQL

header("Content-Type: application/json; charset=UTF-8");

// Đọc dữ liệu JSON từ body
$data = json_decode(file_get_contents("php://input"), true);

// Kiểm tra dữ liệu đầu vào
if (!$data || !isset($data['user_id']) || !isset($data['items']) || !is_array($data['items'])) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Thiếu hoặc sai định dạng dữ liệu"]);
    exit();
}

$user_id = intval($data['user_id']);
$items = $data['items'];

// Tạo cart mới
$stmt = $conn->prepare("INSERT INTO carts (user_id) VALUES (?)");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Lỗi tạo cart: " . $conn->error]);
    exit();
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_id = $stmt->insert_id;
$stmt->close();

// Thêm từng món vào cart_items
$stmt = $conn->prepare("INSERT INTO cart_items (cart_id, food_id, quantity, note) VALUES (?, ?, ?, ?)");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Lỗi chuẩn bị thêm item: " . $conn->error]);
    exit();
}

foreach ($items as $item) {
    $food_id = intval($item['food_id']);
    $quantity = intval($item['quantity']);
    $note = isset($item['note']) ? $item['note'] : '';

    $stmt->bind_param("iiis", $cart_id, $food_id, $quantity, $note);
    $stmt->execute();
}
$stmt->close();

echo json_encode([
    "success" => true,
    "cart_id" => $cart_id
]);
?>
