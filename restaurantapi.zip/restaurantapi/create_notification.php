<?php
header("Content-Type: application/json; charset=UTF-8");
require_once 'db.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Phương thức không được hỗ trợ"
    ]);
    exit;
}

if (!isset($_POST['user_id'], $_POST['order_id'], $_POST['title'], $_POST['message'])) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Thiếu tham số (user_id, order_id, title, message)"
    ]);
    exit;
}

$userId = trim($_POST['user_id']);
$orderId = intval($_POST['order_id']);
$title = trim($_POST['title']);
$message = trim($_POST['message']);

// Kiểm tra user_id có tồn tại trong bảng users không
$checkUser = $conn->prepare("SELECT id FROM users WHERE id = ?");
$checkUser->bind_param("s", $userId);
$checkUser->execute();
$userResult = $checkUser->get_result();

if ($userResult->num_rows === 0) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "user_id không tồn tại trong bảng users"
    ]);
    exit;
}
$checkUser->close();

// Chèn dữ liệu vào notifications
$stmt = $conn->prepare("INSERT INTO notifications (user_id, order_id, title, message) VALUES (?, ?, ?, ?)");
$stmt->bind_param("siss", $userId, $orderId, $title, $message);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Tạo thông báo thành công"
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Lỗi khi tạo thông báo: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
?>
