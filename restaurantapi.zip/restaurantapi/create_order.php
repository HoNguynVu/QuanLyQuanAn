<?php
header("Content-Type: application/json");
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$user_id = $data['user_id'];
$items = $data['items'];
$discount_code = isset($data['discount_code']) ? trim($data['discount_code']) : "";
$address = isset($data['address']) ? $data['address'] : "";

$total_amount = 0;
foreach ($items as $item) {
    $food_id = $item['food_id'];
    $quantity = $item['quantity'];

    // Lấy giá món ăn từ CSDL
    $stmt = $conn->prepare("SELECT price FROM foods WHERE id = ?");
    $stmt->bind_param("i", $food_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $food = $result->fetch_assoc();
        $price = $food['price'];
        $total_amount += $quantity * $price;
    } else {
        echo json_encode(["status" => "error", "message" => "Món ăn ID $food_id không tồn tại"]);
        http_response_code(400);
        exit();
    }
}


// Xử lý giảm giá (nếu có)
$discount_id = null;
$discount_percent = 0;
$max_discount_amount = 0;
$discount_amount = 0;

if (!empty($discount_code)) {
    $stmt = $conn->prepare("SELECT * FROM discounts WHERE code = ? AND is_active = 1 AND valid_from <= CURDATE() AND valid_to >= CURDATE()");
    $stmt->bind_param("s", $discount_code);
    $stmt->execute();
    $discount_result = $stmt->get_result();

    if ($discount_result->num_rows > 0) {
        $discount = $discount_result->fetch_assoc();
        $discount_id = $discount['id'];
        $discount_percent = $discount['discount_percent'];
        $max_discount_amount = $discount['max_discount_amount'];
        $discount_amount = min($total_amount * $discount_percent / 100, $max_discount_amount);
    }
}

$final_amount = $total_amount - $discount_amount;

// Tạo đơn hàng
$stmt = $conn->prepare("INSERT INTO orders (user_id, final_amount, status, address, discount_id) VALUES (?, ?, 'Đang chờ', ?, ?)");
$stmt->bind_param("idsi", $user_id, $final_amount, $address, $discount_id);
$stmt->execute();

$order_id = $stmt->insert_id;

// Chèn từng item vào order_items
foreach ($items as $item) {
    $food_id = $item['food_id'];
    $quantity = $item['quantity'];
    $note = isset($item['note']) && !empty($item['note']) ? $item['note'] : 'Không có';
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, food_id, quantity,note) VALUES (?, ?, ?,?)");
    $stmt->bind_param("iiis", $order_id, $food_id, $quantity,$note);
    $stmt->execute();
}

$response = array(
    "status" => "success",
    "order_id" => $order_id,
    "final_amount" => $final_amount
);

echo json_encode($response);
$conn->close();
?>
