<?php
$host = "localhost";
$user = "root";
$pass = "vudz1234";
$db = "restaurant_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// echo "Kết nối thành công"; // bỏ comment để test
?>
