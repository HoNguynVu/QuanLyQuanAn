<?php
require 'db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Phải dùng POST"]);
    exit;
}

$id = $_POST['id'] ?? '';

if (empty($id)) {
    echo json_encode(["status" => "error", "message" => "Thiếu ID món ăn"]);
    exit;
}

$stmt = $conn->prepare("DELETE FROM foods WHERE id = ?");
$stmt->bind_param("i", $id);
if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Xoá thành công"]);
} else {
    echo json_encode(["status" => "error", "message" => "Lỗi xoá dữ liệu"]);
}
$stmt->close();
$conn->close();
?>
