<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include "db.php"; // Kết nối CSDL

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    
    case 'GET': // Lấy danh sách tất cả mã giảm giá
        $result = $conn->query("SELECT * FROM discounts ORDER BY id DESC");
        $discounts = [];
        while ($row = $result->fetch_assoc()) {
            $row['is_active'] = boolval($row['is_active']);
            $discounts[] = $row;
        }
        echo json_encode($discounts);
        break;


    case 'POST': // Thêm mới mã giảm giá
        $data = json_decode(file_get_contents("php://input"), true);

        if (!isset($data['code'], $data['discount_percent'], $data['max_discount_amount'], $data['valid_from'], $data['valid_to'])) {
            http_response_code(400);
            echo json_encode(["message" => "Thiếu dữ liệu"]);
            exit;
        }
        $is_active = $data['is_active'] ? 1 : 0;
       $stmt = $conn->prepare("INSERT INTO discounts (code, discount_percent, max_discount_amount, valid_from, valid_to, is_active) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
                "sddssi",  // s: string, d: double, d: double, s: string (date), s: string (date)
                $data['code'],
                $data['discount_percent'],
                $data['max_discount_amount'],
                $data['valid_from'],
                $data['valid_to'],
                $is_active
                );

        if ($stmt->execute()) {
            $data['id'] = $stmt->insert_id;
            echo json_encode($data);
        } else {
            http_response_code(500);
            echo json_encode(["message" => "Lỗi thêm dữ liệu"]);
        }
        break;


    case 'PUT': // Cập nhật mã giảm giá
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(["message" => "Thiếu id"]);
            exit;
        }
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);

        $is_active = $data['is_active'] ? 1 : 0;

        $stmt = $conn->prepare("UPDATE discounts SET code=?, discount_percent=?, max_discount_amount=?, valid_from=?, valid_to=?, is_active=? WHERE id=?");
        $stmt->bind_param(
            "sddssii",
            $data['code'],
            $data['discount_percent'],
            $data['max_discount_amount'],
            $data['valid_from'],
            $data['valid_to'],
            $is_active,
            $id
        );

        if ($stmt->execute()) {
            echo json_encode(["message" => "Cập nhật thành công"]);
        } else {
            http_response_code(500);
            echo json_encode(["message" => "Lỗi cập nhật dữ liệu"]);
        }
        break;


    case 'DELETE': // Xóa mã giảm giá
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["message" => "Thiếu id"]);
        exit;
    }
    $id = intval($_GET['id']);

    // Kiểm tra xem có đơn hàng nào đang dùng mã giảm giá này không
    $check_sql = "SELECT COUNT(*) as total FROM orders WHERE discount_id = $id";
    $result = $conn->query($check_sql);
    $row = $result->fetch_assoc();

    if ($row['total'] > 0) {
        http_response_code(409); // 409 Conflict
        echo json_encode(["message" => "Không thể xóa, mã giảm giá đang được sử dụng trong đơn hàng!"]);
    } else {
        if ($conn->query("DELETE FROM discounts WHERE id = $id")) {
            echo json_encode(["message" => "Xóa thành công"]);
        } else {
            http_response_code(500);
            echo json_encode(["message" => "Lỗi xóa dữ liệu: " . $conn->error]);
        }
    }
    break;


    default:
        http_response_code(405);
        echo json_encode(["message" => "Phương thức không hỗ trợ"]);
        break;
}

$conn->close();
?>
