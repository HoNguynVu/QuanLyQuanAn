<?php
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Phải dùng phương thức POST"]);
    exit;
}

$email = $_POST['email'] ?? '';
if (empty($email)) {
    echo json_encode(["status" => "error", "message" => "Thiếu email"]);
    exit;
}

// Kiểm tra email có tồn tại
$check = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();
if ($check->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "Email chưa được đăng ký"]);
    exit;
}

// Tạo OTP và gửi email
$otp = rand(100000, 999999);
$mail = new PHPMailer(true);
try {
    $mail->CharSet = 'UTF-8';  // Để không lỗi tiếng Việt
    $mail->Encoding = 'base64'; // Mã hoá an toàn
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'anhemrotinuit@gmail.com';
    $mail->Password   = 'jnaf slth avkm uibi';
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;
    $mail->setFrom('anhemrotinuit@gmail.com', 'Restaurant App');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'OTP đặt lại mật khẩu cho Restaurant App';
    $mail->Body    = "Mã xác nhận đặt lại mật khẩu là: <b>$otp</b>";
    $mail->send();

    // Lưu OTP tạm
    $stmt = $conn->prepare("REPLACE INTO password_resets (email, otp) VALUES (?, ?)");
    $stmt->bind_param("ss", $email, $otp);
    $stmt->execute();

    echo json_encode(["status" => "otp_sent", "message" => "Mã OTP đã được gửi về email"]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Lỗi gửi email: {$mail->ErrorInfo}"]);
}
?>
