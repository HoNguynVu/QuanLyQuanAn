<?php
require_once 'db.php';

ob_clean();
header('Content-Type: application/json; charset=UTF-8');

$user_id = $_GET['user_id'] ?? null;

if (!$user_id) {
    http_response_code(400);
    echo json_encode(["error" => "Thiếu user_id"]);
    exit();
}

// Lấy cart gần nhất
$cartResult = $conn->prepare("SELECT cart_id FROM carts WHERE user_id = ? ORDER BY cart_id DESC LIMIT 1");
$cartResult->bind_param("i", $user_id);
$cartResult->execute();
$cartResult->bind_result($cart_id);
$cartResult->fetch();
$cartResult->close();

if (!$cart_id) {
    echo json_encode(["items" => []]);
    exit();
}

// Lấy cart_items
$stmt = $conn->prepare("SELECT food_id, quantity, note FROM cart_items WHERE cart_id = ?");
$stmt->bind_param("i", $cart_id);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}

$stmt->close();

echo json_encode(["items" => $items]);
