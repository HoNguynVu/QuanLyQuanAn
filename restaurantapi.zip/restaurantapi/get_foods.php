<?php
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

$stmt = $conn->prepare("SELECT id, name, category, price, image_url, available, description, rating_avg FROM foods");
$stmt->execute();
$result = $stmt->get_result();

$foods = [];
while ($row = $result->fetch_assoc()) {
    $foods[] = $row;
}

echo json_encode([
    "status" => "success",
    "data" => $foods
], JSON_UNESCAPED_UNICODE);
?>
