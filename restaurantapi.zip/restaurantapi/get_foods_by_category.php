<?php
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

$category = $_GET['category'] ?? '';

if (empty($category)) {
    echo json_encode(["status" => "error", "message" => "Thiếu loại món"]);
    exit;
}

if ($category === 'all') {
    // Lấy tất cả món ăn
    $stmt = $conn->prepare("SELECT id, name, category, price, image_url, available, description FROM foods");
} else {
    // Lọc theo loại món
    $stmt = $conn->prepare("SELECT id, name, category, price, image_url, available, description FROM foods WHERE category = ?");
    $stmt->bind_param("s", $category);
}

$stmt->execute();
$result = $stmt->get_result();

$foods = [];
while ($row = $result->fetch_assoc()) {
    $foods[] = $row;
}

echo json_encode(["status" => "success", "data" => $foods], JSON_UNESCAPED_UNICODE);
