<?php
header("Content-Type: application/json");
require_once("db.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $food_id = isset($_POST['food_id']) ? $_POST['food_id'] : '';
    
    if (empty($food_id)) {
        echo json_encode(array("error" => "Missing food_id parameter"));
        exit();
    }
    
    // Truy vấn lấy thông tin món ăn theo ID, có thêm rating_avg
    $sql = "SELECT id, name, category, price, image_url, available, description, rating_avg 
            FROM foods 
            WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $food_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        $food_item = [
            "id" => (int)$row["id"],
            "name" => $row["name"],
            "category" => $row["category"],
            "price" => (float)$row["price"],
            "image_url" => $row["image_url"],
            "available" => (int)$row["available"],
            "description" => $row["description"],
            "rating_avg" => isset($row["rating_avg"]) ? round((float)$row["rating_avg"], 1) : 0.0
        ];
        
        echo json_encode($food_item, JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(array("error" => "Food item not found"));
    }
    
} else {
    echo json_encode(array("error" => "Only POST method allowed"));
}
?>
