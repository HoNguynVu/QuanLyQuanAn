<?php
header('Content-Type: application/json; charset=UTF-8');
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') 
 {
    $user_id = isset($_REQUEST['user_id']) ? intval($_REQUEST['user_id']) : 0;

    if ($user_id <= 0) {
        echo json_encode([]); // Trả về mảng rỗng nếu user_id không hợp lệ
        exit;
    }

    $sql = "SELECT id, user_id, order_id, title, message, is_read, created_at 
            FROM notifications 
            WHERE user_id = $user_id 
            ORDER BY created_at DESC";

    $result = $conn->query($sql);

    $notifications = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            // Ép kiểu boolean cho is_read nếu cần
            $row['is_read'] = (bool)$row['is_read'];
            $notifications[] = $row;
        }
    }

    echo json_encode($notifications, JSON_UNESCAPED_UNICODE);
} else {
    http_response_code(405);
    echo json_encode(["message" => "Phương thức không được hỗ trợ"]);
}
?>
