<?php
header("Content-Type: application/json");
require_once("db.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lấy order_id từ POST data
    $order_id = isset($_POST['order_id']) ? $_POST['order_id'] : '';
    
    if (empty($order_id)) {
        echo json_encode(array("error" => "Missing order_id parameter"));
        exit();
    }
    
    // Truy vấn lấy các món ăn trong đơn hàng
    $sql = "SELECT id, order_id, food_id, quantity, note 
            FROM order_items 
            WHERE order_id = ? 
            ORDER BY id";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $order_items = [];
    
    while ($row = $result->fetch_assoc()) {
        $order_items[] = [
            "id" => $row["id"],
            "order_id" => $row["order_id"],
            "food_id" => $row["food_id"],
            "quantity" => (int)$row["quantity"],
            "note" => $row["note"] ? $row["note"] : ""
        ];
    }
    
    echo json_encode($order_items);
    
} else {
    echo json_encode(array("error" => "Only POST method allowed"));
}
?>
