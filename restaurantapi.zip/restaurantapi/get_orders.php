<?php
header("Content-Type: application/json");
require_once("db.php");

// Truy vấn danh sách đơn hàng kèm thông tin khách hàng và mã giảm giá (nếu có)
$sql = "SELECT 
            o.id, 
            o.user_id, 
            u.name AS customer_name, 
            u.phone,
            o.final_amount, 
            o.status, 
            o.created_at, 
            o.address, 
            o.discount_id,
            d.code AS discount_code,
            d.discount_percent
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id
        LEFT JOIN discounts d ON o.discount_id = d.id
        ORDER BY o.created_at DESC";

$result = $conn->query($sql);
$orders = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = [
            "id" => $row["id"],
            "user_id" => (int)$row["user_id"],
            "customer_name" => $row["customer_name"] ?? "Khách hàng không xác định",
            "phone" => $row["phone"] ?? "",
            "final_amount" => (float)$row["final_amount"],
            "status" => $row["status"],
            "created_at" => $row["created_at"],
            "address" => $row["address"],
            "discount_code" => $row["discount_code"] ?? null,
            "discount_percent" => $row["discount_percent"] ? (int)$row["discount_percent"] : 0
        ];
    }
    echo json_encode($orders);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Lỗi truy vấn cơ sở dữ liệu"]);
}
?>
