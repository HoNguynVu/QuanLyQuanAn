<?php
require_once 'db.php';

header('Content-Type: application/json; charset=utf-8');

$email = $_POST['email'] ?? '';

if (empty($email)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email is required']);
    exit;
}

// Lấy user_id từ bảng users
$sqlUser = "SELECT id FROM users WHERE email = ?";
$stmtUser = $conn->prepare($sqlUser);
$stmtUser->bind_param("s", $email);

if (!$stmtUser->execute()) {
    http_response_code(500);
    echo json_encode(['error' => 'Query user failed']);
    exit;
}

$resultUser = $stmtUser->get_result();
$user = $resultUser->fetch_assoc();

if (!$user) {
    http_response_code(404);
    echo json_encode(['error' => 'User not found']);
    exit;
}

$user_id = $user['id'];
$stmtUser->close();

// Lấy danh sách đơn hàng, JOIN với bảng discounts để lấy discount_percent
$sql = "
    SELECT 
        orders.id,
        orders.user_id,
        orders.status,
        orders.created_at,
        orders.final_amount,
        orders.address,
        discounts.discount_percent
    FROM orders
    LEFT JOIN discounts ON orders.discount_id = discounts.id
    WHERE orders.user_id = ?
    ORDER BY orders.created_at DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $orders = [];

    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }

    echo json_encode($orders);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Query orders failed']);
}

$stmt->close();
$conn->close();
?>
