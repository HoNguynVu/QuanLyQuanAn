<?php
require_once 'db.php'; // kết nối MySQL

header("Content-Type: application/json; charset=UTF-8");

// Câu truy vấn: tính tổng quantity theo food_id
$sql = "
    SELECT 
        f.id,
        f.name,
        f.price,
        f.category,
        f.available,
        f.description,
        f.rating_avg,
        f.image_url,
        SUM(oi.quantity) AS total_ordered
    FROM order_items oi
    JOIN foods f ON oi.food_id = f.id
    GROUP BY oi.food_id
    ORDER BY total_ordered DESC
    LIMIT 10
";

$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Lỗi truy vấn: " . $conn->error
    ]);
    exit();
}

$topFoods = [];

while ($row = $result->fetch_assoc()) {
    $topFoods[] = [
        "id" => (int)$row['id'],
        "name" => $row['name'],
        "price" => (float)$row['price'],
        "image_url" => $row['image_url'],
        "total_ordered" => (int)$row['total_ordered'],
        "category" => $row['category'],
        "available" => (int)$row['available'],
        "description" => $row['description'],
        "rating_avg" => (float)$row['rating_avg'],
    ];
}

echo json_encode([
    "success" => true,
    "data" => $topFoods
]);
?>
