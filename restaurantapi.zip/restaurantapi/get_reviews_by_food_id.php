<?php
header("Content-Type: application/json; charset=UTF-8");
require_once 'db.php';

if (!isset($_GET['food_id']) || empty($_GET['food_id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Thiếu food_id"]);
    exit();
}

$foodId = $conn->real_escape_string($_GET['food_id']);

// Dùng đúng tên cột review_id thay vì id
$sql = "SELECT id AS review_id, user_id, food_id, comment, rating, created_at AS review_date FROM reviews WHERE food_id = '$foodId'";
$result = $conn->query($sql);

$reviews = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $reviews[] = [
            "review_id" => $row["review_id"],
            "user_id" => $row["user_id"],
            "food_id" => $row["food_id"],
            "comment" => $row["comment"],
            "rating" => floatval($row["rating"]),
            "review_date" => $row["review_date"]
        ];
    }
}

echo json_encode($reviews);
$conn->close();
?>
