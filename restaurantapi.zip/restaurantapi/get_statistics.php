<?php
header("Content-Type: application/json");
require_once("db.php"); // Kết nối MySQL

// Tổng đơn hàng (đã hoàn tất)
$totalOrdersResult = $conn->query("SELECT COUNT(*) AS total_orders FROM orders WHERE status = 'Đã giao'");
$totalOrders = $totalOrdersResult->fetch_assoc()['total_orders'];

// Doanh thu hôm nay (đơn đã hoàn tất)
$today = date('Y-m-d');
$todayRevenueResult = $conn->query("
    SELECT SUM(final_amount) AS today_revenue 
    FROM orders 
    WHERE DATE(created_at) = '$today' AND status = 'Đã giao'
");
$todayRevenue = $todayRevenueResult->fetch_assoc()['today_revenue'] ?? 0;

// Doanh thu tháng hiện tại (đơn đã hoàn tất)
$currentMonth = date('m');
$currentYear = date('Y');
$monthlyRevenueResult = $conn->query("
    SELECT SUM(final_amount) AS monthly_revenue 
    FROM orders 
    WHERE MONTH(created_at) = '$currentMonth' AND YEAR(created_at) = '$currentYear' AND status = 'Đã giao'
");
$monthlyRevenue = $monthlyRevenueResult->fetch_assoc()['monthly_revenue'] ?? 0;

// Tổng doanh thu (tất cả đơn đã hoàn tất)
$totalRevenueResult = $conn->query("
    SELECT SUM(final_amount) AS total_revenue 
    FROM orders 
    WHERE status = 'Đã giao'
");
$totalRevenue = $totalRevenueResult->fetch_assoc()['total_revenue'] ?? 0;

// Trả kết quả
echo json_encode([
    "total_orders" => (int)$totalOrders,
    "today_revenue" => (float)$todayRevenue,
    "monthly_revenue" => (float)$monthlyRevenue,
    "total_revenue" => (float)$totalRevenue
]);
?>
