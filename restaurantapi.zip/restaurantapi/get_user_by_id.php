<?php
header("Content-Type: application/json");
require_once("db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'] ?? '';
    
    if (empty($user_id)) {
        echo json_encode(['error' => 'User ID is required']);
        exit;
    }
    
    $sql = "SELECT id, name, email, phone FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
    echo json_encode([
        "status" => "success",
        "message" => "Lấy thông tin thành công",
        "user" => $row
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["status" => "error", "message" => "Không tìm thấy admin"], JSON_UNESCAPED_UNICODE);
}
    
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['error' => 'Only POST requests allowed']);
}
?>
