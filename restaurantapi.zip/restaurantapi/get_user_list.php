<?php
include "db.php";

$adminId = isset($_GET['admin_id']) ? intval($_GET['admin_id']) : 0;

$sql = "
    SELECT 
        u.id, u.email, u.name, u.phone, u.date_birth, u.role,
        (
            SELECT MAX(m.timestamp) 
            FROM messages m 
            WHERE (m.sender_id = u.id AND m.receiver_id = ?) 
               OR (m.sender_id = ? AND m.receiver_id = u.id)
        ) AS last_message_time
    FROM users u
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $adminId, $adminId);
$stmt->execute();
$result = $stmt->get_result();

$users = [];
while ($row = $result->fetch_assoc()) {
    $userId = $row['id'];

    $checkUnread = $conn->prepare("SELECT COUNT(*) as unread_count FROM messages WHERE sender_id = ? AND receiver_id = ? AND is_read = 0");
    $checkUnread->bind_param("ii", $userId, $adminId);
    $checkUnread->execute();
    $unreadResult = $checkUnread->get_result()->fetch_assoc();
    $checkUnread->close();

    $row['has_unread'] = $unreadResult['unread_count'] > 0;

    $users[] = $row;
}

echo json_encode($users);
?>
