<?php
header('Content-Type: application/json');
require_once 'db.php';

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (!$email || !$password) {
    echo json_encode(["status" => "error", "message" => "Thiếu email hoặc mật khẩu"]);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    if ($user['password'] === $password) { // ⚠️ Nếu bạn mã hóa mật khẩu, dùng password_verify()
        unset($user['password']); // Xóa mật khẩu khỏi dữ liệu trả về
        echo json_encode(["status" => "success", "data" => $user]);
    } else {
        echo json_encode(["status" => "error", "message" => "Sai mật khẩu"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Tài khoản không tồn tại"]);
}
$conn->close();
?>
