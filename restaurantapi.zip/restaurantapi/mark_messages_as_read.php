<?php
include "db.php";

$sender_id = isset($_POST['sender_id']) ? intval($_POST['sender_id']) : 0;
$receiver_id = isset($_POST['receiver_id']) ? intval($_POST['receiver_id']) : 0;

$response = ["success" => false];

if ($sender_id > 0 && $receiver_id > 0) {
    $stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0");
    $stmt->bind_param("ii", $sender_id, $receiver_id);

    if ($stmt->execute()) {
        $response["success"] = true;
    }
    $stmt->close();
}

echo json_encode($response);
?>
