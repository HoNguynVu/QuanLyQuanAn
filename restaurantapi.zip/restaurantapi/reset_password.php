<?php
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

$email = $_POST['email'] ?? '';
$new_password = $_POST['new_password'] ?? '';

if (empty($email) || empty($new_password)) {
    echo json_encode(["status" => "error", "message" => "Thiếu thông tin"], JSON_UNESCAPED_UNICODE);
    exit;
}

// Cập nhật mật khẩu mới
$stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
$stmt->bind_param("ss", $new_password, $email);
$stmt->execute();
$stmt->close();

// Xoá OTP sau khi đổi xong
$conn->query("DELETE FROM password_resets WHERE email = '$email'");

echo json_encode(["status" => "success", "message" => "Đổi mật khẩu thành công"], JSON_UNESCAPED_UNICODE);
