<?php
require_once 'db.php';
header('Content-Type: application/json');

$code = $_POST['code'] ?? '';

$response = [];

if (empty($code)) {
    $response['success'] = false;
    $response['message'] = "Vui lòng nhập mã giảm giá.";
    echo json_encode($response);
    exit;
}

$dateToday = date('Y-m-d');

$stmt = $conn->prepare("
    SELECT id, discount_percent, max_discount_amount 
    FROM discounts 
    WHERE code = ? 
      AND is_active = 1 
      AND valid_from <= ? 
      AND valid_to >= ?
    LIMIT 1
");
$stmt->bind_param("sss", $code, $dateToday, $dateToday);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $discount = $result->fetch_assoc();
    $response['success'] = true;
    $response['discount'] = $discount;
} else {
    $response['success'] = false;
    $response['message'] = "Mã không hợp lệ hoặc đã hết hạn.";
}

$stmt->close();
$conn->close();

echo json_encode($response);
