<?php
// ======================= SIGNUP.PHP =======================
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Phải dùng phương thức POST"], JSON_UNESCAPED_UNICODE);
    exit;
}

// Lấy dữ liệu từ POST
$email      = $_POST['email']      ?? '';
$name       = $_POST['name']       ?? '';
$password   = $_POST['password']   ?? '';
$phone      = $_POST['phone']      ?? '';
$date_birth = $_POST['date_birth'] ?? '';
$role       = $_POST['role']       ?? 'User';

// Kiểm tra thiếu thông tin
if (empty($email) || empty($name) || empty($password) || empty($phone) || empty($date_birth)) {
    echo json_encode(["status" => "error", "message" => "Thiếu thông tin cần thiết"], JSON_UNESCAPED_UNICODE);
    exit;
}

// Kiểm tra email đã tồn tại trong users
$checkEmail = $conn->prepare("SELECT id FROM users WHERE email = ?");
$checkEmail->bind_param("s", $email);
$checkEmail->execute();
$checkEmail->store_result();
if ($checkEmail->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "Email đã được đăng ký"], JSON_UNESCAPED_UNICODE);
    exit;
}
$checkEmail->close();

// Kiểm tra số điện thoại đã tồn tại trong users
$checkPhone = $conn->prepare("SELECT id FROM users WHERE phone = ?");
$checkPhone->bind_param("s", $phone);
$checkPhone->execute();
$checkPhone->store_result();
if ($checkPhone->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "Số điện thoại đã được đăng ký"], JSON_UNESCAPED_UNICODE);
    exit;
}
$checkPhone->close();

// Nếu đã tồn tại email trong pending_users thì xoá để ghi lại bản mới
$checkPending = $conn->prepare("SELECT email FROM pending_users WHERE email = ?");
$checkPending->bind_param("s", $email);
$checkPending->execute();
$checkPending->store_result();
if ($checkPending->num_rows > 0) {
    $checkPending->close();
    $stmtDel = $conn->prepare("DELETE FROM pending_users WHERE email = ?");
    $stmtDel->bind_param("s", $email);
    $stmtDel->execute();
    $stmtDel->close();
} else {
    $checkPending->close();
}



// Nếu đã tồn tại email trong pending_users thì xoá để ghi lại bản mới
$check2 = $conn->prepare("SELECT email FROM pending_users WHERE email = ?");
$check2->bind_param("s", $email);
$check2->execute();
$check2->store_result();
if ($check2->num_rows > 0) {
    $check2->close();
    $stmt = $conn->prepare("DELETE FROM pending_users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->close();
} else {
    $check2->close();
}

// Tạo mã OTP
$otp = rand(100000, 999999);

// Gửi email
$mail = new PHPMailer(true);
try {
    $mail->CharSet = 'UTF-8';  // Để không lỗi tiếng Việt
    $mail->Encoding = 'base64'; // Mã hoá an toàn
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'anhemrotinuit@gmail.com';        // Gmail thật
    $mail->Password   = 'jnaf slth avkm uibi';            // App password
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('anhemrotinuit@gmail.com', 'Restaurant App');
    $mail->addAddress($email, $name);
    $mail->isHTML(true);
    $mail->Subject = 'Thông tin đăng ký từ Restaurant App';
    $mail->Body    = "<h3>Xin chào <b>$name</b>!</h3><p>Mã xác nhận đăng ký của bạn là: <strong>$otp</strong></p>";

    $mail->send();

    // Lưu tạm vào bảng pending_users
    $stmt = $conn->prepare("INSERT INTO pending_users (email, name, password, phone, date_birth, role, otp) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $email, $name, $password, $phone, $date_birth, $role, $otp);
    $stmt->execute();
    $stmt->close();

    echo json_encode(["status" => "otp_sent", "message" => "Mã xác nhận đã được gửi tới email"], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Gửi email thất bại: {$mail->ErrorInfo}"], JSON_UNESCAPED_UNICODE);
}
?>
