<?php
header("Content-Type: application/json");
include 'db.php'; // Kết nối đến cơ sở dữ liệu

// Nhận dữ liệu từ Android app
$email = $_POST['email'] ?? '';
$name = $_POST['name'] ?? '';
$phone = $_POST['phone'] ?? '';
$date_birth = $_POST['date_birth'] ?? '';

// Kiểm tra dữ liệu đầu vào
if (empty($email) || empty($name) || empty($phone) || empty($date_birth)) {
    echo json_encode([
        "success" => false,
        "message" => "Thiếu dữ liệu đầu vào"
    ]);
    exit;
}

// Truy vấn cập nhật thông tin
$sql = "UPDATE users SET name = ?, phone = ?, date_birth = ? WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $name, $phone, $date_birth, $email);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Cập nhật thông tin thành công"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Cập nhật thất bại"
    ]);
}

$stmt->close();
$conn->close();
?>
