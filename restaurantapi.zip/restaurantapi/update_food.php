<?php
header("Content-Type: application/json");
require_once("db.php"); // Đảm bảo đã include file kết nối

// Lấy dữ liệu từ POST
$id         = $_POST['id'] ?? '';
$name       = $_POST['name'] ?? '';
$category   = $_POST['category'] ?? '';
$price      = $_POST['price'] ?? '';
$image_url  = $_POST['image_url'] ?? '';
$available  = $_POST['available'] ?? ''; // Lấy thêm available
$description = $_POST['description'] ?? '';

// Kiểm tra dữ liệu bắt buộc
if (empty($id) || empty($name) || empty($category) || empty($price) || empty($image_url) || $available === '' || empty($description)) {
    echo json_encode(["success" => false, "message" => "Thiếu dữ liệu"]);
    exit;
}

// Chuẩn bị và thực thi truy vấn cập nhật
$stmt = $conn->prepare("UPDATE foods SET name = ?, category = ?, price = ?, image_url = ?, available = ?, description = ? WHERE id = ?");
$stmt->bind_param("ssdsisi", $name, $category, $price, $image_url, $available, $description, $id);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "status" => "success", "message" => "Cập nhật thành công"]);
} else {
    echo json_encode(["success" => false, "message" => "Lỗi khi cập nhật"]);
}

$stmt->close();
$conn->close();
?>
