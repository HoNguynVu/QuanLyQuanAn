<?php
require_once("db.php");
header("Content-Type: application/json");

$orderId = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
$newStatus = $_POST['status'] ?? '';

if ($orderId <= 0 || $newStatus === '') {
    echo json_encode(["success" => false, "message" => "Thiếu dữ liệu"]);
    exit;
}

// Lấy trạng thái cũ của đơn hàng
$oldStatus = '';
$stmt = $conn->prepare("SELECT status FROM orders WHERE id = ?");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$stmt->bind_result($oldStatus);
$stmt->fetch();
$stmt->close();

// Nếu trạng thái không thay đổi thì không làm gì cả
if ($newStatus === $oldStatus) {
    echo json_encode(["success" => true, "message" => "Trạng thái không thay đổi"]);
    exit;
}

// Kiểm tra các quy tắc chuyển trạng thái
// 1. Không được hủy đơn hàng khi đang giao hoặc đã giao
if ($newStatus === 'Hủy' && ($oldStatus === 'Đang giao' || $oldStatus === 'Đã giao')) {
    echo json_encode([
        "success" => false, 
        "message" => "Không thể hủy đơn hàng khi đang ở trạng thái '$oldStatus'"
    ]);
    exit;
}

// 2. Không được chuyển từ trạng thái "Hủy" sang trạng thái khác
if ($oldStatus === 'Hủy' && $newStatus !== 'Hủy') {
    echo json_encode([
        "success" => false,
        "message" => "Không thể thay đổi trạng thái của đơn hàng đã bị hủy"
    ]);
    exit;
}

// Lấy danh sách món ăn trong đơn hàng
$stmt = $conn->prepare("SELECT food_id, quantity FROM order_items WHERE order_id = ?");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$result = $stmt->get_result();
$orderItems = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Xử lý thay đổi số lượng món ăn theo trạng thái
// Nếu chuyển sang "Đã tiếp nhận" thì kiểm tra tất cả món trước khi trừ số lượng
if ($newStatus === 'Đã tiếp nhận') {
    $insufficientItems = [];
    
    // Kiểm tra tất cả món có đủ hàng không
    foreach ($orderItems as $item) {
        $foodId = $item['food_id'];
        $quantity = $item['quantity'];
        
        $stmt = $conn->prepare("SELECT available, name FROM foods WHERE id = ?");
        $stmt->bind_param("i", $foodId);
        $stmt->execute();
        $stmt->bind_result($available, $foodName);
        $stmt->fetch();
        $stmt->close();
        
        if ($available < $quantity) {
            $insufficientItems[] = "Món '$foodName' không đủ hàng (còn $available, cần $quantity)";
        }
    }
    
    // Nếu có món không đủ hàng thì báo lỗi tất cả
    if (!empty($insufficientItems)) {
        $errorMessage = "Không thể tiếp nhận đơn hàng:\n" . implode("\n", $insufficientItems);
        echo json_encode([
            "success" => false,
            "message" => $errorMessage
        ]);
        exit;
    }
    
    // Nếu tất cả món đều đủ hàng thì mới trừ số lượng
    foreach ($orderItems as $item) {
        $foodId = $item['food_id'];
        $quantity = $item['quantity'];
        $conn->query("UPDATE foods SET available = available - $quantity WHERE id = $foodId");
    }
}

// Nếu từ "Đã tiếp nhận" → "Hủy" thì cộng lại số lượng
elseif ($newStatus === 'Hủy' && $oldStatus === 'Đã tiếp nhận') {
    foreach ($orderItems as $item) {
        $foodId = $item['food_id'];
        $quantity = $item['quantity'];
        $conn->query("UPDATE foods SET available = available + $quantity WHERE id = $foodId");
    }
}

// Cập nhật trạng thái đơn hàng
$stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
$stmt->bind_param("si", $newStatus, $orderId);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Cập nhật trạng thái thành công"]);
} else {
    echo json_encode(["success" => false, "message" => "Lỗi khi cập nhật trạng thái", "error" => $stmt->error]);
}

$stmt->close();
$conn->close();
