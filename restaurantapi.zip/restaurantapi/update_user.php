<?php
require_once 'db.php'; // kết nối MySQL

$email = $_POST['email'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$dob = $_POST['dob'];

$sql = "UPDATE users SET name=?, phone=?, date_birth=? WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $name, $phone, $dob, $email);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
