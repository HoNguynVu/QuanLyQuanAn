<?php
header("Content-Type: application/json");

// Thư mục lưu ảnh (trong cùng thư mục với file PHP)
$target_dir = "uploads/";

// Tạo thư mục nếu chưa có
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0777, true);
}

// Nhận dữ liệu ảnh từ POST
$image_base64 = $_POST['image'] ?? '';

if (empty($image_base64)) {
    echo json_encode([
        "success" => false,
        "message" => "Không có ảnh gửi lên"
    ]);
    exit;
}

// Giải mã base64 → ảnh
$image_data = base64_decode($image_base64);
$file_name = uniqid() . ".jpg";
$file_path = $target_dir . $file_name;

// Lưu file ảnh
if (file_put_contents($file_path, $image_data)) {
    $server_name = $_SERVER['SERVER_NAME'];
    $image_url = "http://$server_name/restaurantapi/uploads/$file_name";

    echo json_encode([
        "success" => true,
        "url" => $image_url
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Lỗi khi lưu ảnh"
    ]);
}
?>
