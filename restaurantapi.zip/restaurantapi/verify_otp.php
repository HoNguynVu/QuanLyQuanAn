<?php
// ======================= VERIFY_OTP.PHP =======================
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

$otp = $_POST['otp'] ?? '';

if (empty($otp)) {
    echo json_encode(["status" => "error", "message" => "Thiếu mã OTP"], JSON_UNESCAPED_UNICODE);
    exit;
}

// Truy vấn xem mã OTP có tồn tại không
$stmt = $conn->prepare("SELECT * FROM pending_users WHERE otp = ?");
$stmt->bind_param("s", $otp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "Sai mã OTP hoặc đã hết hạn"], JSON_UNESCAPED_UNICODE);
    exit;
}

$user = $result->fetch_assoc();
$stmt->close();

// Thêm vào bảng users
$insert = $conn->prepare("INSERT INTO users (email, name, password, phone, date_birth, role) VALUES (?, ?, ?, ?, ?, ?)");
$insert->bind_param(
    "ssssss",
    $user['email'],
    $user['name'],
    $user['password'],
    $user['phone'],
    $user['date_birth'],
    $user['role']
);

if ($insert->execute()) {
    // Xóa khỏi pending_users
    $del = $conn->prepare("DELETE FROM pending_users WHERE email = ?");
    $del->bind_param("s", $user['email']);
    $del->execute();
    $del->close();

    echo json_encode(["status" => "success", "message" => "Tạo tài khoản thành công!"], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["status" => "error", "message" => "Lỗi khi lưu tài khoản chính thức"], JSON_UNESCAPED_UNICODE);
}

$insert->close();
$conn->close();
