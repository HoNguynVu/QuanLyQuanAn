<?php
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

$email = $_POST['email'] ?? '';
$otp   = $_POST['otp'] ?? '';

if (empty($email) || empty($otp)) {
    echo json_encode(["status" => "error", "message" => "Thiếu email hoặc mã OTP"], JSON_UNESCAPED_UNICODE);
    exit;
}

// Kiểm tra OTP có khớp không
$stmt = $conn->prepare("SELECT id FROM password_resets WHERE email = ? AND otp = ?");
$stmt->bind_param("ss", $email, $otp);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "Mã OTP không đúng hoặc đã hết hạn"], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["status" => "success", "message" => "Mã OTP hợp lệ"], JSON_UNESCAPED_UNICODE);
}
$stmt->close();
